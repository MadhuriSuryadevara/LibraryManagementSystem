package com.lms.bean;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class LibraryInfo {
	List<BookInfo> bookList;
	Double totalFine;
	public List<BookInfo> getBookList() {
		return bookList;
	}
	public void setBookList(List<BookInfo> bookList) {
		this.bookList = bookList;
	}
	public Double getFine() {
		return totalFine;
	}
	public void setFine(Double fine) {
		this.totalFine = fine;
	}
	public LibraryInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public LibraryInfo(List<BookInfo> bookList, Double totalFine) {
		super();
		this.bookList = bookList;
		this.totalFine = totalFine;
	}
}

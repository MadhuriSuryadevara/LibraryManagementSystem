package com.lms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lms.bean.Admin;
import com.lms.bean.Book;
import com.lms.service.IAdminService;

@RestController
@RequestMapping("/admin")
//@CrossOrigin(origins = "http://localhost:4200")
public class AdminController {

	@Autowired
	IAdminService iAdminService;
	
	@GetMapping("/login")
	public Admin checkLoginDetails(@RequestParam String adminEmail, String password) {
		System.out.println(adminEmail);
		Admin admin=iAdminService.checkLoginDetails(adminEmail,password);
		if(admin != null)
		{
			return admin;
		}
		return null;
	}
	
	@PostMapping("/register")
	public Boolean register(@RequestBody Admin admin) {
		if(iAdminService.addDetails(admin))
			return true;
		return false;
	}
	
	@PostMapping("/addbook")
	public Boolean addBook(@RequestBody Book book) {
		if(book==null) {
			return false;
		}
		return iAdminService.addBook(book);
	}
	
	@PostMapping("/updatebook")
	public Boolean updateBook(@RequestParam String bookId,int noOfBooksToBeAdded) {
		return iAdminService.updateBook(bookId,noOfBooksToBeAdded);
	}
	
	@DeleteMapping("/deletebook")
	public Boolean deleteBook(@RequestParam String bookId) {
		return iAdminService.deleteBook(bookId);
	}
	
	@PostMapping("/issuebook")
	public Boolean issueBook(@RequestParam String issueId,String studentId) {
		return iAdminService.issueBook(issueId,studentId);
	}
	
	@PostMapping("/rejectIssue")
	public Boolean rejectIssue(@RequestParam String issueId,String studentId) {
		return iAdminService.rejectIssue(issueId,studentId);
	}
	
	@GetMapping("/calculateFine")
	public Double calculateFine(@RequestParam String studentId) {
		return iAdminService.calculateFine(studentId);
	}


}

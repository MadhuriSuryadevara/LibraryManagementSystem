package com.lms.dao;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.lms.bean.Admin;
import com.lms.bean.Book;
import com.lms.bean.BookInfo;
import com.lms.bean.LibraryInfo;
import com.lms.bean.Request;
import com.lms.bean.Student;


@Repository
public class AdminDaoImpl implements IAdminDao{
	
	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public Admin checkLoginDetails(String adminEmail, String password) {
		Query query=new Query();
		query.addCriteria(Criteria.where("adminEmail").is(adminEmail));
		Admin admin=mongoTemplate.findOne(query, Admin.class);
		if(admin != null) {
			if(admin.getPassword().matches(password))
				return admin;
		}
		return null;
	}

	@Override
	public Boolean addDetails(Admin admin) {
		Query query=new Query();
		query.addCriteria(Criteria.where("adminEmail").is(admin.getAdminEmail()));
		if(mongoTemplate.findOne(query, Admin.class)==null)
		{
			mongoTemplate.insert(admin);
			return true;
		}
		
		return false;
	}

	@Override
	public Boolean addBook(Book book) {
		Query query =new Query();
		query.addCriteria(Criteria.where("bookId").is(book.getBookId()));
		if(mongoTemplate.findById(query, Book.class)==null) {
			mongoTemplate.insert(book);
			return true;
		}
		return false;
	}

	@Override
	public Boolean updateBook(String bookId, int noOfBooks) {
		Query query =new Query();
		query.addCriteria(Criteria.where("bookId").is(bookId));
		Book book=mongoTemplate.findById(query, Book.class);
		if(book!=null) {
			book.setNoOfBooks(book.getNoOfBooks()+noOfBooks);
			mongoTemplate.save(book);
			return true;
		}
		return false;
	}

	@Override
	public Boolean deleteBook(String bookId) {
		Query query=new Query();
		query.addCriteria(Criteria.where("bookId").is(bookId));
		Book book=mongoTemplate.findById(query, Book.class);
		if(book!=null) {
			mongoTemplate.remove(query, Book.class);
			return true;
		}
		return false;
	}

	@Override
	public Boolean issueBook(String issueId,String studentId) {
		Query studentQuery=new Query();
		studentQuery.addCriteria(Criteria.where("studentId").is(studentId));
		Student student=mongoTemplate.findById(studentQuery, Student.class);
		if(student.getLibraryInfo()==null) {
			return false;
		}
		LibraryInfo libraryInfos=student.getLibraryInfo();
		if(libraryInfos.getBookList()==null) {
			return false;
		}
		List<BookInfo> bookInfos=libraryInfos.getBookList();
		Iterator<BookInfo> iter = bookInfos.iterator();
		while(iter.hasNext()) {
			BookInfo bookInfo=iter.next();
			if(bookInfo.getIssueId().equalsIgnoreCase(issueId)) {
				Query removeRequest=new Query();
				removeRequest.addCriteria(Criteria.where("issueId").is(issueId));
				mongoTemplate.findAndRemove(removeRequest, Request.class);
				LocalDate date=LocalDate.now();
				bookInfo.setIssueDate(date);
				bookInfo.setStatus("issued");
				bookInfo.setDueDate(date.plusDays(15));
				Query query=new Query();
				query.addCriteria(Criteria.where("bookId").is(bookInfo.getBookId()));
				Book book=new Book();
				book.setNoOfBooks(book.getNoOfBooks()-1);
				mongoTemplate.save(book);
				mongoTemplate.save(student);
				return true;
			}
		}
		return false;
	}

	@Override
	public Double calculateFine(String studentId) {
		Query query=new Query();
		query.addCriteria((Criteria.where("studentId").is(studentId)));
		Student student=mongoTemplate.findById(query, Student.class);
		if(student!=null) {
			if(student.getLibraryInfo()!=null) {
				LibraryInfo libraryInfo=student.getLibraryInfo();
				if(libraryInfo.getBookList()==null) {
					return 0.0;
				}
				else {
					return libraryInfo.getFine();
				}
			}
			else {
				return 0.0;
			}
		}
		return null;
	}

	@Override
	public Boolean rejectIssue(String issueId, String studentId) {
		Query studentQuery=new Query();
		studentQuery.addCriteria(Criteria.where("studentId").is(studentId));
		Student student=mongoTemplate.findById(studentQuery, Student.class);
		if(student.getLibraryInfo()==null) {
			return false;
		}
		LibraryInfo libraryInfos=student.getLibraryInfo();
		if(libraryInfos.getBookList()==null) {
			return false;
		}
		List<BookInfo> bookInfos=libraryInfos.getBookList();
		Iterator<BookInfo> iter = bookInfos.iterator();
		while(iter.hasNext()) {
			BookInfo bookInfo=iter.next();
			if(bookInfo.getIssueId().equalsIgnoreCase(issueId)) {
				Query removeRequest=new Query();
				removeRequest.addCriteria(Criteria.where("issueId").is(issueId));
				mongoTemplate.findAndRemove(removeRequest, Request.class);
				bookInfo.setIssueDate(null);
				bookInfo.setStatus("rejected");
				bookInfo.setDueDate(null);
				mongoTemplate.save(student);
				return true;
			}
		}
		return false;
	}
}

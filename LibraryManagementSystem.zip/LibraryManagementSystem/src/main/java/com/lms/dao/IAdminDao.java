package com.lms.dao;

import com.lms.bean.Admin;
import com.lms.bean.Book;

public interface IAdminDao {

	Admin checkLoginDetails(String adminEmail, String password);

	Boolean addDetails(Admin admin);

	Boolean addBook(Book book);

	Boolean updateBook(String bookId, int noOfBooks);

	Boolean deleteBook(String bookId);

	Boolean issueBook(String issueId, String studentId);

	Double calculateFine(String studentId);

	Boolean rejectIssue(String issueId, String studentId);

}

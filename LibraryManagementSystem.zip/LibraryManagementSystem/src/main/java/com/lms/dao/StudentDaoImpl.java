package com.lms.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.lms.bean.Book;
import com.lms.bean.BookInfo;
import com.lms.bean.LibraryInfo;
import com.lms.bean.Request;
import com.lms.bean.Student;

@Repository
public class StudentDaoImpl implements IStudentDao {
 
	static int issueId=1;
	
	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public String addDetails(Student student) {
		if(checkUser(student.getEmail())!=null)
		return null;
		mongoTemplate.save(student);
		return "saved";
	}
	
	public Student checkUser(String email) {
		Query query=new Query();
		query.addCriteria(Criteria.where("email").is(email));
		return mongoTemplate.findOne(query,Student.class);
	}
	

	@Override
	public Student checkLoginDetails(String email, String password) {
		Student student=checkUser(email);
		if(student==null)
		{
			return null;
		}
		return student;
	}

	@Override
	public List<Book> getAllBooks() {
		return mongoTemplate.findAll(Book.class);
	}

	@Override
	public Boolean borrowBook(String bookId, String studentId) {
		Query query =new Query();
		query.addCriteria(Criteria.where("bookId").is(bookId));
		Book book=mongoTemplate.findById(query, Book.class);
		Query studentQuery=new Query();
		studentQuery.addCriteria(Criteria.where("studentId").is(studentId));
		Student student=mongoTemplate.findById(studentQuery, Student.class);
		if(book.getNoOfBooks()!=0) {
			if(student.getLibraryInfo()==null) {
				student.setLibraryInfo(new LibraryInfo());
			}
			LibraryInfo libraryInfos=student.getLibraryInfo();
			if(libraryInfos.getBookList()==null) {
				libraryInfos.setBookList(new ArrayList<BookInfo>());
			}
			List<BookInfo> bookInfos=libraryInfos.getBookList();
			BookInfo bookInfo=new BookInfo();
			bookInfo.setBookId(book.getBookId());
			bookInfo.setBookName(book.getBookName());
			bookInfo.setStatus("pending");
			bookInfo.setBookAuthor(book.getBookAuthor());
			LocalDate date=LocalDate.now();
			bookInfo.setIssueDate(date);
			bookInfo.setDueDate(date.plusDays(15));
			bookInfos.add(bookInfo);
			libraryInfos.setBookList(bookInfos);
			student.setLibraryInfo(libraryInfos);
			Request request=new Request();
			List<Request> requests=mongoTemplate.findAll(Request.class);
			if(requests==null) {
				request.setIssueId(issueId);
			}
			else {
				Iterator<Request> iter=requests.iterator();
				while(iter.hasNext()) {
					Request request2=iter.next();
					if(request2.getIssueId()==issueId) {
						issueId++;
					}
				}
			}
			request.setIssueId(issueId);
			request.setBookAuthor(book.getBookAuthor());
			request.setBookName(book.getBookName());
			request.setStudentId(studentId);
		}
		return false;
	}

	@Override
	public Double returnBook(String issueId, String studentId) {
		/*
		 * Query query =new Query();
		 * query.addCriteria(Criteria.where("bookId").is(bookId)); Book
		 * book=mongoTemplate.findById(query, Book.class); Query studentQuery=new
		 * Query(); studentQuery.addCriteria(Criteria.where("studentId").is(studentId));
		 * Student student=mongoTemplate.findById(studentQuery, Student.class);
		 */
		return null;
	}
}
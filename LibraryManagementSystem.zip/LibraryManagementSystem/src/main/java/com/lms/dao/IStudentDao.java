package com.lms.dao;

import java.util.List;

import com.lms.bean.Book;
import com.lms.bean.Student;

public interface IStudentDao {
	
	String addDetails(Student student);
	Student checkLoginDetails(String email, String password);
	List<Book> getAllBooks();
	Boolean borrowBook(String bookId, String studentId);
	Double returnBook(String issueId, String studentId);

}
